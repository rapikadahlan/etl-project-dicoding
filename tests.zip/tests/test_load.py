import pandas as pd
from utils.load import save_to_csv


def test_save_csv(tmp_path):
    df = pd.DataFrame({
        "Title": ["Test"],
        "Price": [100],
        "Rating": [4.5],
        "Colors": [2],
        "Size": ["M"],
        "Gender": ["Men"]
    })

    file = tmp_path / "test.csv"

    save_to_csv(df, file)

    # File berhasil dibuat
    assert file.exists()

    # File tidak kosong
    saved_df = pd.read_csv(file)
    assert not saved_df.empty

    # Kolom sesuai
    assert list(saved_df.columns) == ["Title", "Price", "Rating", "Colors", "Size", "Gender"]