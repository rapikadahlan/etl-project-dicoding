from unittest.mock import patch, Mock
from utils.extract import fetch_page

@patch("utils.extract.requests.Session")
def test_fetching_content_success(mock_session):
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.content = b"<html><body>Test</body></html>"
    mock_session.return_value.get.return_value = mock_response

    result = fetch_page("https://example.com")

    assert result == b"<html><body>Test</body></html>"